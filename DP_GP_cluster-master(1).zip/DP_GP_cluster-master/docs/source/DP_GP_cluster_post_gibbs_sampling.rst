DP_GP_cluster_post_gibbs_sampling module
========================================

.. automodule:: DP_GP_cluster_post_gibbs_sampling
    :members:
    :undoc-members:
    :show-inheritance:
