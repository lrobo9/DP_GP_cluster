Installation
============

Install dependencies::

    conda install pandas numpy scipy matplotlib cython scikit-learn

Download source code and uncompress, then::

    python setup.py install